<?php
defined('BASEPATH') or exit('No direct script access allowed');

// $route['default_controller'] = 'dashboard/index';
$route['default_controller'] = 'login';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
